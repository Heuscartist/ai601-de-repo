from prefect import task, flow, get_run_logger
import pandas as pd
import matplotlib.pyplot as plt


@task
def fetch_data(file_path):
    logger = get_run_logger()
    logger.info("Reading data...")
    df = pd.read_csv(file_path)
    logger.info(f"Data shape: {df.shape}")
    return df


@task
def validate_data(df):
    logger = get_run_logger()
    logger.info("Validating data...")
    missing_values = df.isnull().sum()
    logger.info(f"Missing values:\n{missing_values}")
    # Drop rows with missing values
    df_clean = df.dropna()
    return df_clean


@task
def transform_data(df_clean):
    logger = get_run_logger()
    logger.info("Transforming data...")
    if "sales" in df_clean.columns:
        df_clean["sales_normalized"] = (df_clean["sales"] - df_clean["sales"].mean()) / df_clean["sales"].std()
    return df_clean


@task
def generate_analytics_report(df_clean, output_file):
    logger = get_run_logger()
    logger.info("Generating analytics report...")
    summary = df_clean.describe()
    summary.to_csv(output_file)
    logger.info(f"Summary statistics saved to {output_file}")


@task
def create_sales_histogram(df_clean, output_file):
    logger = get_run_logger()
    logger.info("Creating sales histogram...")
    if "sales" in df_clean.columns:
        plt.hist(df_clean["sales"], bins=20)
        plt.title("Sales Distribution")
        plt.xlabel("Sales")
        plt.ylabel("Frequency")
        plt.savefig(output_file)
        plt.close()
        logger.info(f"Sales histogram saved to {output_file}")


@flow
def analytics_pipeline(file_path, summary_output, histogram_output):
    # Step 1: Fetch data
    df = fetch_data(file_path)

    # Step 2: Validate data
    df_clean = validate_data(df)

    # Step 3: Transform data
    df_clean = transform_data(df_clean)

    # Step 4: Generate analytics report
    generate_analytics_report(df_clean, summary_output)

    # Step 5: Create sales histogram
    create_sales_histogram(df_clean, histogram_output)

    print("Analytics pipeline completed.")


if __name__ == "__main__":
    file_path = "analytics_data.csv"
    summary_output = "analytics_summary.csv"
    histogram_output = "sales_histogram.png"
    
    analytics_pipeline(file_path, summary_output, histogram_output)

